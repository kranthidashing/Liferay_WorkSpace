package com.mappingportlet.constants;

/**
 * @author kranthi.kumar
 */
public class MappingPortletKeys {

	public static final String Mapping = "Mapping";

}