create table Ashokleyland_UserExternal (
	uuid_ VARCHAR(75) null,
	uid LONG not null primary key,
	Location VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null
);